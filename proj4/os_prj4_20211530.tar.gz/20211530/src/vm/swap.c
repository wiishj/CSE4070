#include "vm/swap.h"

#define BLOCK_PER_PAGE 8 //4096/512

struct lock swap_lock;

void swap_init(void){
     swap_block=block_get_role(BLOCK_SWAP);
     swap=bitmap_create(1<<13);
     lock_init(&swap_lock);
}

void swap_in(size_t used_index, void* kaddr){ /*fetch to memory from swap area*/

     lock_acquire(&swap_lock);
     if(bitmap_test(swap, used_index)){
          for(int i=0; i<BLOCK_PER_PAGE; i++){
               block_read(swap_block , used_index*BLOCK_PER_PAGE +i , kaddr+BLOCK_SECTOR_SIZE*i);
          }
          bitmap_flip(swap, used_index);
          lock_release(&swap_lock);
     }
}

size_t swap_out(void *kaddr){ /*fetch data to swap area from memory*/

     lock_acquire(&swap_lock);
	size_t swap_index = bitmap_scan_and_flip(swap, 0, 1, false);

     if(swap_index!=BITMAP_ERROR){
		for (int i=0; (size_t) i<BLOCK_PER_PAGE; i++) {
			block_write (swap_block, BLOCK_PER_PAGE * swap_index + i, BLOCK_SECTOR_SIZE * i + kaddr);
		}
          lock_release(&swap_lock);
	}
	return swap_index;
}

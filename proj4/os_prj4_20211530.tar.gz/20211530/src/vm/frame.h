#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <hash.h>
#include <list.h>
#include "threads/synch.h"
#include "vm/page.h"
#include "threads/palloc.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "vm/swap.h"

struct list lru_list;
struct lock lru_lock;
struct list_elem *lru_clock;

void init_lrulist(void);
void add_to_lrulist(struct page *page);
void delete_from_lrulist(struct page* page);

void clock_algorithm();
struct page *alloc_page (enum palloc_flags flags);
void free_page (void *kdaar);

#endif

#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <hash.h>
#include <list.h>
#include "lib/kernel/bitmap.h"
#include "devices/block.h"
#include "vm/page.h"
#include "vm/frame.h"

struct bitmap *swap;
struct block *swap_block;

void swap_init(void);
void swap_in(size_t used_index, void *kaddr);
size_t swap_out(void *kaddr);
#endif

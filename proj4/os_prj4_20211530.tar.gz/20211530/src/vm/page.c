#include <string.h>
#include <stdio.h>
#include "threads/malloc.h"
#include "threads/vaddr.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "userprog/pagedir.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"


unsigned vme_addr(const struct hash_elem *e, void *aux UNUSED);
bool cmp_vaddr(const struct hash_elem *a, const struct hash_elem *b, void *aux UNUSED);
void destructor(struct hash_elem *e, void *aux UNUSED);

unsigned vme_addr(const struct hash_elem *e, void *aux UNUSED){
     struct vm_entry *vme=hash_entry(e, struct vm_entry, elem);
     return hash_int((int)vme->vaddr);
}
bool cmp_vaddr(const struct hash_elem *a, const struct hash_elem *b, void *aux UNUSED){

     return hash_entry(a, struct vm_entry, elem)->vaddr < hash_entry(b, struct vm_entry, elem)->vaddr;
}

void destructor(struct hash_elem *e, void *aux UNUSED){
      struct vm_entry *vme=hash_entry(e, struct vm_entry, elem);
     if(vme->is_loaded==false) {
          free(vme);
          return;
     }
     
     void *kaddr=pagedir_get_page(thread_current()->pagedir, vme->vaddr);
     free_page(kaddr);
     pagedir_clear_page(thread_current()->pagedir, vme->vaddr);

     free(vme);
}

void init_vm(struct hash *vm){
     hash_init(vm, vme_addr, cmp_vaddr, NULL);
}

void destroy_vm(struct hash *vm){
     hash_destroy(vm, destructor);
}

struct vm_entry *find_vme(void *vaddr){
     struct vm_entry *vme=(struct vm_entry*)malloc(sizeof(struct vm_entry));
     vme->vaddr=pg_round_down(vaddr); //return starting point of virtual address pointed va
     struct hash_elem *e=hash_find(&thread_current()->vm, &(vme->elem));

     return e==NULL?NULL:hash_entry(e, struct vm_entry, elem);
}

bool insert_vme(struct hash *vm, struct vm_entry *vme){
     return hash_insert(vm, &(vme->elem))==NULL?true:false;
}

bool delete_vme(struct hash *vm, struct vm_entry *vme){
     bool flag=hash_delete(vm, &(vme->elem))==NULL ? false : true;
     free(vme);
     return flag;
}

bool load_file(void *paddr, struct vm_entry *vme){ 
     ASSERT(vme->type==VM_BIN);

     struct file *file=filesys_open(vme->file);
     if(file_read_at(file, paddr, vme->read_bytes, vme->offset)==(int)vme->read_bytes){
          memset(paddr+vme->read_bytes, 0, vme->zero_bytes);
          return true;
     }
     return false;
}

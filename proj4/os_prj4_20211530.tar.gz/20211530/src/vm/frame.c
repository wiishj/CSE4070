#include "frame.h"
#include <stdio.h>

/* search the next clock in the LRU list */
static struct list_elem *
next_lru_clock (void)
{

	if(list_empty(&lru_list) || (!lru_clock&&list_begin(&lru_list)==list_end(&lru_list))) return;
     
     if(lru_clock==NULL || (!lru_clock && lru_clock==list_end(&lru_clock))) return list_begin(&lru_list);
     
	if(list_next(lru_clock)==list_end(&lru_list)) return list_begin(&lru_list);
	
	else return list_next(lru_clock);
}

void
init_lrulist (void)
{
	list_init (&lru_list);
	lock_init (&lru_lock);
	lru_clock = NULL;
}

/* insert an user page to the end of the LRU list */
void
add_to_lrulist (struct page *page)
{	
	if(!page) return;
	lock_acquire(&lru_lock);
	list_push_back (&lru_list, &(page->lru));
	lock_release(&lru_lock);
}

/* delete an user page at the end of the LRU list */
void
delete_from_lrulist (struct page *page)
{
	if(!page) return;
	if (lru_clock==&page->lru)
		lru_clock = list_next (lru_clock);

	list_remove (&page->lru);
}

void clock_algorithm(void){
     
     lru_clock=next_lru_clock();
     lock_acquire(&lru_lock);
     if(!lru_clock){
          lock_release(&lru_lock);
          return;
     }
     struct page *victim=list_entry(lru_clock, struct page, lru);

     while(pagedir_is_accessed(victim->thread->pagedir, victim->vme->vaddr)){ //find page with not leacently accessed
          pagedir_set_accessed(victim->thread->pagedir, victim->vme->vaddr, 0);
		lru_clock=next_lru_clock();
          if(!lru_clock){
               lock_release(&lru_lock);
               return;
          }
		victim=list_entry(lru_clock, struct page, lru);
     }
     if(pagedir_is_dirty(victim->thread->pagedir, victim->vme->vaddr)){ //Is data written?
          victim->vme->type=VM_ANON;
          victim->vme->swap_slot=swap_out(victim->kaddr);
     }
     else if(victim->vme->type==VM_ANON){
          victim->vme->swap_slot=swap_out(victim->kaddr);
     }
     victim->vme->is_loaded=false;
     pagedir_clear_page(victim->thread->pagedir, victim->vme->vaddr);
     delete_from_lrulist(victim);
     palloc_free_page(victim->kaddr);
     free(victim);
     lock_release(&lru_lock);
     return;
}

struct page *
alloc_page (enum palloc_flags flags)
{
	//lock_acquire (&lru_lock);
	
	uint8_t *kpage = palloc_get_page (flags);
	while (kpage == NULL) {
		clock_algorithm();
		kpage = palloc_get_page (flags);
	}
	struct page *page = malloc (sizeof (struct page));
	page->kaddr = kpage;
	page->thread = thread_current ();

	add_to_lrulist (page);

	//lock_release (&lru_lock);

	return page;
}

void free_page(void *paddr){
     struct list_elem *e;
     struct page *page=NULL;

     lock_acquire(&lru_lock);
     for(struct list_elem *e=list_begin(&lru_list) ; e!=list_end(&lru_list); e=list_next(e)){
          page=list_entry(e, struct page, lru);
          if(page->kaddr == paddr){
               delete_from_lrulist(page);
               palloc_free_page(page->kaddr);
               free(page);
               break;
          }
     }

     lock_release(&lru_lock);
}



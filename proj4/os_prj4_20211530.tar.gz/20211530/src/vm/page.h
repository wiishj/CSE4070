#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include <list.h>
#include "threads/thread.h"
#include "threads/vaddr.h"
/*definition for load data*/
#define VM_BIN 0 //in binary file
#define VM_ANON 1 //in dsik

struct vm_entry{//entry of virtual memory
     uint8_t type;
     
     void *vaddr;

     bool is_loaded;
     bool writable;

     size_t offset;
     size_t read_bytes;
     size_t zero_bytes;

     char *file;
     size_t swap_slot;

     struct hash_elem elem;
};

struct page{ //page in supplemental page table
     void *kaddr; //physical address of page
     struct vm_entry *vme;
     struct thread *thread; 
     struct list_elem lru;
};

void init_vm(struct hash *vm);
void destroy_vm(struct hash *vm);

struct vm_entry *find_vme(void *vaddr);
bool insert_vme(struct hash *vm, struct vm_entry *vme);
bool delete_vme(struct hash *vm, struct vm_entry *vme);

bool load_file(void *paddr, struct vm_entry *vme);

#endif
#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"

void syscall_init(void);
void check_address(void *addr);
void syscall_halt(void);
void syscall_exit(int status);
pid_t syscall_exec(const char *file);
int syscall_wait(pid_t);
int syscall_read(int fd, void *buffer, unsigned length);
int syscall_write(int fd, const void *buffer, unsigned length);
int syscall_fibonacci(int n);
int syscall_max_of_four_int(int a, int b, int c, int d);
#endif /* userprog/syscall.h */

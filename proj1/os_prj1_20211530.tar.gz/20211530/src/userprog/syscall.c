#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/vaddr.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"

static void syscall_handler(struct intr_frame *);

void syscall_init(void)
{
  intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}
void check_address(void *addr)
{
  if (!is_user_vaddr(addr))
    syscall_exit(-1);
}
static void
syscall_handler(struct intr_frame *f UNUSED)
{
  /*printf ("system call!\n");
  thread_exit ();*/
  // printf("syscall %d \n ", *(uint32_t *)(f->esp));
  switch (*(uint32_t *)(f->esp))
  {
  case SYS_HALT:
    syscall_halt();
    break;
  case SYS_EXIT:
    check_address(f->esp + 4);
    syscall_exit(*(uint32_t *)(f->esp + 4));
    break;
  case SYS_EXEC:
    check_address(f->esp + 4);
    f->eax = syscall_exec((const char *)*(uint32_t *)(f->esp + 4));
    break;
  case SYS_WAIT:
    check_address(f->esp + 4);
    f->eax = syscall_wait((pid_t) * (uint32_t *)(f->esp + 4));
    break;
  case SYS_READ:
    f->eax = syscall_read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*(uint32_t *)(f->esp + 12));
    break;
  case SYS_WRITE:
    f->eax = syscall_write((int)*(uint32_t *)(f->esp + 4), (const void *)*(uint32_t *)(f->esp + 8), (unsigned)*(uint32_t *)(f->esp + 12));
    break;
  case SYS_FIB:
    f->eax = syscall_fibonacci((int)*(uint32_t *)(f->esp + 4));
    break;
  case SYS_MAX:
    f->eax = syscall_max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
    break;
  }
  return;
}
void syscall_halt(void)
{
  shutdown_power_off();
}
void syscall_exit(int status)
{
  // check wheter program normally exits or not(normal : return 0)
  thread_current()->exit_status = status;
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_exit();
}
pid_t syscall_exec(const char *file)
{
  return process_execute(file);
}
int syscall_wait(pid_t pid)
{
  return process_wait((tid_t)pid);
}
int syscall_read(int fd, void *buffer, unsigned length)
{
  if (fd != 0)
    return -1;
  int i;
  for (i = 0; i < (int)length; i++)
  {
    if (input_getc() == '\0')
      break;
  }
  return i;
}

int syscall_write(int fd, const void *buffer, unsigned length)
{
  if (fd != 1)
    return -1;
  putbuf((char *)buffer, (size_t)length);
  return length;
}

int syscall_fibonacci(int n)
{
  if (n == 1)
    return 1;
  else if (n == 2)
    return 1;
  int sum = 0, x = 1, y = 1;
  for (int i = 3; i <= n; i++)
  {
    sum = x + y;
    x = y;
    y = sum;
  }
  return sum;
}

int syscall_max_of_four_int(int a, int b, int c, int d)
{
  int max = (a > b) ? a : b;
  max = (max > c) ? max : c;
  max = (max > d) ? max : d;
  return max;
}